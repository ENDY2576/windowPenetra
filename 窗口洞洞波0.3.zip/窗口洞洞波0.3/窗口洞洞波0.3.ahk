﻿; <COMPILER: v1.1.37.01>
#InstallKeybdHook
#UseHook
#SingleInstance Force
; 防「71 hotkeys」洪水警告框：按住 ` 时键盘自动重复会以 ~30/s 触发热键，
; 默认 70/2000ms 阈值必然弹模态框并冻结交互。放宽到 5000/100ms 仅作兜底，
; 真正的修复在 $`:: 体里用 backtickHeld 标志 + GetKeyState 直接忽略自动重复。
#MaxHotkeysPerInterval 5000
#HotkeyInterval 100
#MaxThreadsPerHotkey 2
DetectHiddenWindows On
; 标题用「包含」匹配，这样窗口标题里加版本标记也不会影响 WinActive 判断
SetTitleMatchMode, 2

; 构建标记：build.py 编译时会替换成实际时间。
; 用途：一眼看出「托盘里跑的是哪个版本」——踩过坑：改了 exe 但常驻的旧实例还在跑，
; 结果所有修复都没生效，还以为是代码没改对。
buildTag := "build 09-14 17:54"

; =======================================================================
;  窗口洞洞波 v0.3
;  在原版 0.2 基础上新增：
;   1. 托盘菜单 + 设置面板，宽度/高度/圆角/刷新间隔均为可拖拽滑块，边拖边生效
;   2. 形状可选：正圆（调半径）/ 椭圆 / 矩形（可圆角）/ 三角形 / 心形，参数可自定义
;   3. 浏览器/视频窗口兼容模式：去 DWM 圆角 + SetWindowPos 重排 + 强制重绘
;   4. 穿透关闭时收缩动画（动画用低分辨率区域 + 跳过强制重绘，避免掉帧卡顿）
;   5. 开洞时默认不最小化其他窗口 —— 洞后面就是「下层窗口本人」，看得到也点得到；
;      想回到 0.2 的老行为（洞后露桌面）可在设置面板勾选
; =======================================================================

iniPath := A_ScriptDir "\setting.ini"

; --------------------------- 读取设置 ---------------------------
; 兼容 0.2：旧 ini 的 [radius] radius 里存的是「半径」，外接尺寸 = 半径 × 2
IniRead, legacyRadius, %iniPath%, radius, radius, 300
if legacyRadius is not integer
    legacyRadius := 300
defW := legacyRadius * 2

IniRead, shape, %iniPath%, settings, shape, circle
if shape not in circle,ellipse,rect,triangle,heart
    shape := circle

IniRead, width, %iniPath%, settings, width, %defW%
IniRead, height, %iniPath%, settings, height, %defW%
IniRead, corner, %iniPath%, settings, corner, 0
IniRead, rate, %iniPath%, settings, rate, 20
; 关闭动画风格：0=无动画 1=仅收缩 2=渐变过渡（透明→内容）。兼容旧版 anim 键；旧 animMode=3 统一落到 2。
IniRead, animMode, %iniPath%, settings, animMode, %A_Space%
if (animMode = " " || animMode = "")
    IniRead, animMode, %iniPath%, settings, anim, 1
animMode := (animMode >= 0 && animMode <= 3) ? animMode : 1
if (animMode = 3)        ; 旧版「收缩+渐变消失」已废弃，统一落到「柔和收洞」(2)
    animMode := 2
IniRead, compatMode, %iniPath%, settings, compat, 1
; 默认 0 = 开洞时不最小化其他窗口，洞后面直接就是「后面的窗口」本身。
; 设成 1 则是旧版 0.2 的行为：先把其他窗口最小化，洞后面露出桌面。
IniRead, minimizeOthers, %iniPath%, settings, minothers, 0
minimizeOthers := (minimizeOthers = 1) ? 1 : 0
; 0 = 长按 0.6s 开洞、松手常驻（默认，沿用当前行为）；1 = 按住才穿透（按住期间开洞，松手即关）
IniRead, penMode, %iniPath%, settings, penmode, 0
penMode := (penMode = 1) ? 1 : 0
IniRead, winlist, %iniPath%, winlist
if (winlist = "ERROR")
    winlist := ""

if width is not integer
    width := 600
if height is not integer
    height := 600
if corner is not integer
    corner := 0
if rate is not integer
    rate := 20
width := Clamp(width, 60, 2400)
height := Clamp(height, 60, 2400)
corner := Clamp(corner, 0, 300)
rate := Clamp(rate, 10, 500)

inverted := false
g_scale := 1.0
g_animRegion := 0
g_animLog := 0
settingsHwnd := 0
HoleHwnd1 := 0
HoleHwnd2 := 0
; 多层穿透：除最前层(HoleHwnd1)外，已打洞的后续层（由 Ctrl+↑/↓ 维护）
g_deepHwnds := []
g_deepTimers := []
g_deepOrigCorner := []
g_deepOrigBackdrop := []
g_acOutside := 0             ; 自动关闭：记录“前台离开隧道”的起始时刻（防点击穿透瞬间误关）
g_acAnchor := 0              ; 自动关闭：开洞时刻的前台窗口（锚点）——切窗判定以此为基准，避免开洞瞬间误关
g_compatHwnds := []         ; 已被关掉 DWM 背景材质（主洞）的窗口列表
g_compatOrigCorner := []     ; 各窗原始圆角偏好（属性 33），与上面平行
g_compatOrigBackdrop := []   ; 各窗原始背景材质（属性 38），与上面平行
animTarget := 1
animStart := 0
animDurMs := 220
animSlow := 0
redrawTick := 0
g_useFade := 0              ; 关闭时用分层覆盖窗做「透明→内容」交叉淡入（mode 2）
g_fadeOk := 0
g_fadeHwnd := 0
g_fadeDC := 0
g_fadeBmp := 0
g_fadeX := 0
g_fadeY := 0
g_fadeWW := 0
g_fadeWH := 0
minimizedList := ""
previewScheduled := 0
previewHwnd := 0
prevW := 152
prevH := 150
prevX := 408
prevY := 44
BuildRegion()

; --------------------------- 托盘菜单 ---------------------------
Menu, Tray, NoStandard
Menu, Tray, Add, 设置..., MenuSettings
Menu, Tray, Add, 开机自启动, MenuAutostart
Menu, Tray, Add
Menu, Tray, Add, 使用说明, MenuHelp
Menu, Tray, Add, 退出, MenuExit
Menu, Tray, Default, 设置...
Menu, Tray, Tip, % "窗口洞洞波 v0.3  " buildTag
; 托盘图标固定用本程序自带的 0.2 版 logo（红色印章）
Menu, Tray, Icon, %A_ScriptFullPath%
UpdateAutostartMenu()

OnExit("exit")
running := 0
running2 := 0
Toggle := 0
backtickHeld := 0
StartTime := 0
g_longPressMs := 600    ; 反引号长按开洞阈值（毫秒）：按住达到此值即开洞（无需松开）
g_debug := 0             ; /debug 启动时为 1，写 debug_log.txt 排查热键
SetWinDelay, -1
ListLines, off
; 提高系统定时器精度：默认 15.6ms 的粒度会让 SetTimer 跑不快，动画容易发顿。
; 退出时会 timeEndPeriod 还原（挂在 OnExit 的 exit() 里）。
DllCall("winmm\timeBeginPeriod", "uint", 1)

; 命令行开关：
;   /settings  直接打开设置面板
;   /punch     直接在鼠标下的窗口挖洞（不用按键）；之后按一下 ` 即可关闭
;   /animlog   把开合动画每帧的时间戳写到 anim_log.txt（排查卡顿用）
if (A_Args.Length() > 0)
{
    for k, a in A_Args
    {
        if (a = "/settings")
            Gosub, MenuSettings
        else if (a = "/punch")
            Gosub, DoOpen
        else if (a = "/animlog")
            g_animLog := 1
        else if (a = "/debug")
            g_debug := 1
    }
}
dbg("START buildTag=" . buildTag . " g_debug=" . g_debug . " penMode=" . penMode)
return

; --------------------------- 调试日志（仅 /debug 时写入） ---------------------------
dbg(msg) {
    global g_debug
    if ! g_debug
        return
    FileAppend, % msg . "`n", % A_ScriptDir "\debug_log.txt"
}

; =======================================================================
;  托盘菜单响应
; =======================================================================
MenuSettings:
    snapShape := shape
    snapWidth := width
    snapHeight := height
    snapCorner := corner
    snapRate := rate
    snapAnim := animMode
    snapCompat := compatMode
    snapMinOthers := minimizeOthers
    snapPenMode := penMode
    snapWinlist := winlist
    snapAuto := IsAutostartOn() ? 1 : 0

    shapeIdx := ShapeToIndex(shape)
    animChoice := animMode + 1
    compatState := (compatMode = 0) ? 0 : 1
    minOthersState := (minimizeOthers = 0) ? 0 : 1
    penModeState := (penMode = 1) ? 1 : 0
    ; 正圆在面板上编辑的是「半径」，其余形状编辑外接宽度
    uiSize := (shape = "circle") ? Round(width / 2) : width

    Gui, Settings:New, +HwndSettingsHwnd, % "窗口洞洞波 - 设置  [" buildTag "]"
    Gui, Settings:Font, S9, Microsoft YaHei UI

    Gui, Settings:Add, Text, x16 y20 w84 h20, 形    状：
    Gui, Settings:Add, DDL, vSetShape x104 y16 w170 AltSubmit Choose%shapeIdx% gShapeChanged, 正圆|椭圆|矩形（可圆角）|三角形|心形
    SetShape := shapeIdx

    Gui, Settings:Add, Text, vLblSize1 x16 y56 w84 h20, 宽    度：
    Gui, Settings:Add, Slider, vSetWidth x104 y52 w176 ToolTip gWidthChanged Range60-2400, %uiSize%
    GuiControlGet, hSetWidth, Hwnd, SetWidth
    Gui, Settings:Add, Edit, vSetWidthEdit x290 y50 w64 h24 gWidthEditChanged Number, %uiSize%
    Gui, Settings:Add, Text, vUnit1 x358 y56 w40 h20, 像素

    Gui, Settings:Add, Text, vLblSize2 x16 y92 w84 h20, 高    度：
    Gui, Settings:Add, Slider, vSetHeight x104 y88 w176 ToolTip gHeightChanged Range60-2400, %height%
    GuiControlGet, hSetHeight, Hwnd, SetHeight
    Gui, Settings:Add, Edit, vSetHeightEdit x290 y86 w64 h24 gHeightEditChanged Number, %height%
    Gui, Settings:Add, Text, vUnit2 x358 y92 w40 h20, 像素

    Gui, Settings:Add, Text, vLblCorner x16 y128 w84 h20, 圆    角：
    Gui, Settings:Add, Slider, vSetCorner x104 y124 w176 ToolTip gCornerChanged Range0-300, %corner%
    GuiControlGet, hSetCorner, Hwnd, SetCorner
    Gui, Settings:Add, Edit, vSetCornerEdit x290 y122 w64 h24 gCornerEditChanged Number, %corner%
    Gui, Settings:Add, Text, vUnitCorner x358 y128 w40 h20, 像素

    Gui, Settings:Add, Text, x16 y164 w84 h20, 刷新间隔：
    Gui, Settings:Add, Slider, vSetRate x104 y160 w176 ToolTip gRateChanged Range10-500, %rate%
    GuiControlGet, hSetRate, Hwnd, SetRate
    Gui, Settings:Add, Edit, vSetRateEdit x290 y158 w64 h24 gRateEditChanged Number, %rate%
    Gui, Settings:Add, Text, x358 y164 w40 h20, 毫秒

    Gui, Settings:Add, Text, x%prevX% y18 w152 h20, 当前形状预览：
    Gui, Settings:Add, Picture, vPreviewPic x%prevX% y%prevY% w%prevW% h%prevH% +0xE
    GuiControlGet, previewHwnd, Hwnd, PreviewPic
    Gui, Settings:Add, Text, vPreviewInfo x%prevX% y198 w152 h44

    Gui, Settings:Add, CheckBox, vSetAutoStart x16 y200 w330 h22 Checked%snapAuto%, 开机自动启动（写入当前用户注册表）
    Gui, Settings:Add, Text, x16 y230 w120 h20, 关闭动画风格：
    Gui, Settings:Add, DDL, vSetAnimMode x140 y226 w210 AltSubmit Choose%animChoice%, 无动画|仅收缩|渐变过渡（透明→内容）
    Gui, Settings:Add, CheckBox, vSetCompat x16 y256 w330 h22 Checked%compatState%, 浏览器 / 视频窗口兼容模式（去圆角＋强制重绘）
    Gui, Settings:Add, CheckBox, vSetMinOthers x16 y284 w400 h22 Checked%minOthersState%, 开洞时最小化其他窗口（勾选=洞后露桌面）
    Gui, Settings:Add, CheckBox, vSetPenMode x16 y312 w520 h22 Checked%penModeState%, 按住才穿透：按住期间开洞、松手即关（不勾=长按0.6s开洞、松手常驻）

    Gui, Settings:Add, Text, x16 y338 w544 h20, 挖洞时不需要最小化的程序（每行一个进程名；仅勾选上面复选框时有效）：
    Gui, Settings:Add, Edit, vSetWinlist x16 y362 w544 r5 Multi, %winlist%

    Gui, Settings:Add, Button, gBtnSaveSettings x186 y462 w120 h30 Default, 保存并关闭
    Gui, Settings:Add, Button, gBtnRevertSettings x316 y462 w100 h30, 还原
    Gui, Settings:Add, Button, gBtnDefaultSettings x426 y462 w130 h30, 恢复默认值

    Gui, Settings:Add, Button, gBtnClearResidue x16 y500 w200 h28, 清除穿透残留
    Gui, Settings:Add, Text, vClearResidueMsg x226 y503 w340 h24

    Gui, Settings:Show, w576 h534
    UpdateShapeControls()
    Preview()
return

MenuAutostart:
    SetAutostartOn(!IsAutostartOn())
    UpdateAutostartMenu()
return

MenuHelp:
    helpText := "【基本用法】`n"
    helpText .= "1. 把鼠标放到目标窗口上，按住 `` 键（Esc 下方、Tab 上方）不放：该窗口会被挖出一个跟随鼠标的洞，点击可穿透到下层窗口。`n"
    helpText .= "2. 松开 `` 键：洞会按设置面板里选的「关闭动画风格」隐没（仅收缩 / 渐变过渡），之前让开的其他窗口会静默还原。`n"
    helpText .= "3. 穿透期间按住 1 键可临时开第二个洞，松开即关闭。`n"
    helpText .= "4. 快速连按两次 `` 会输出一个 `` 字符本身。`n`n"
    helpText .= "【托盘图标】`n"
    helpText .= "单击 / 右键托盘图标 → 设置面板：拖拽滑块即可实时调整大小与形状`n"
    helpText .= "（正圆调「半径」，椭圆 / 矩形调宽高，矩形另可调圆角，三角形调边长，心形调宽度）；也可切换开机自启动。`n`n"
    helpText .= "设置面板底部有「清除穿透残留」按钮：万一关洞 / 退出后洞口卡住不消失，点一下即可手动把残留洞口清掉。`n`n"
    helpText .= "【洞后面看到的是什么】`n"
    helpText .= "默认不勾「开洞时最小化其他窗口」：洞后面就是紧挨着的下层窗口本人，可以直接看、也能点击穿透过去。`n"
    helpText .= "若勾上该项（0.2 的老行为）：开洞时先把其他窗口最小化，洞后面露出的是桌面，所以看起来会是一片灰。`n`n"
    helpText .= "【浏览器 / 视频窗口发虚】`n"
    helpText .= "Chromium 系浏览器用 GPU 合成画面，改窗口区域时系统可能把旧画面拉伸，看起来一片模糊。`n"
    helpText .= "1) 保持“兼容模式”勾选；`n"
    helpText .= "2) 若装了 Windhawk 之类的窗口美化工具，可先把浏览器进程（如 msedge.exe）加入其排除名单，或临时退出 Windhawk 复测。`n"
    helpText .= "（实测：挖洞本身对 Edge / Chrome / 资源管理器都是有效的，穿透不了通常不是挖洞机制的问题）"
    MsgBox, 64, 窗口洞洞波 - 使用说明, %helpText%
return

MenuExit:
    ExitApp
return

; =======================================================================
;  设置面板交互
; =======================================================================
ShapeChanged:
    Gui, Settings:Submit, NoHide
    newShape := ShapeFromIndex(SetShape)
    ; 用「切换前」的形状语义把控件值换算成外接宽高，避免切换形状时洞的大小突然跳变
    if (shape = "circle")
    {
        curW := SetWidth * 2
        curH := curW
    }
    else if (shape = "ellipse") or (shape = "rect")
    {
        curW := SetWidth
        curH := SetHeight
    }
    else
    {
        curW := SetWidth
        curH := SetWidth
    }
    shape := newShape
    width := Clamp(curW, 60, 2400)
    height := Clamp(curH, 60, 2400)
    UpdateShapeControls()
    SyncControls()
    BuildRegion()
    RequestPreview()
    if running
        RefreshActiveHoles()
return

WidthChanged:
    Gui, Settings:Submit, NoHide
    GuiControl, Settings:, SetWidthEdit, %SetWidth%
    ApplyLive()
return
WidthEditChanged:
    Gui, Settings:Submit, NoHide
    if SetWidthEdit is not integer
        return
    SetWidthEdit := Clamp(SetWidthEdit, 60, 2400)
    GuiControl, Settings:, SetWidth, %SetWidthEdit%
    ApplyLive()
return

HeightChanged:
    Gui, Settings:Submit, NoHide
    GuiControl, Settings:, SetHeightEdit, %SetHeight%
    ApplyLive()
return
HeightEditChanged:
    Gui, Settings:Submit, NoHide
    if SetHeightEdit is not integer
        return
    SetHeightEdit := Clamp(SetHeightEdit, 60, 2400)
    GuiControl, Settings:, SetHeight, %SetHeightEdit%
    ApplyLive()
return

CornerChanged:
    Gui, Settings:Submit, NoHide
    GuiControl, Settings:, SetCornerEdit, %SetCorner%
    ApplyLive()
return
CornerEditChanged:
    Gui, Settings:Submit, NoHide
    if SetCornerEdit is not integer
        return
    SetCornerEdit := Clamp(SetCornerEdit, 0, 300)
    GuiControl, Settings:, SetCorner, %SetCornerEdit%
    ApplyLive()
return

RateChanged:
    Gui, Settings:Submit, NoHide
    GuiControl, Settings:, SetRateEdit, %SetRate%
return
RateEditChanged:
    Gui, Settings:Submit, NoHide
    if SetRateEdit is not integer
        return
    GuiControl, Settings:, SetRate, %SetRateEdit%
return

BtnSaveSettings:
    Gui, Settings:Submit, NoHide
    PullShapeState()
    rate := Clamp(SetRate, 10, 500)
    animMode := SetAnimMode - 1
    compatMode := SetCompat ? 1 : 0
    minimizeOthers := SetMinOthers ? 1 : 0
    penMode := SetPenMode ? 1 : 0
    winlist := RegExReplace(SetWinlist, "`r`n", "`n")
    winlist := Trim(winlist, "`r`n ")
    BuildRegion()
    SetAutostartOn(SetAutoStart = 1)
    UpdateAutostartMenu()
    SaveIni()
    Gui, Settings:Destroy
    settingsHwnd := 0
    TrayTip, 窗口洞洞波, 设置已保存。新的尺寸与形状立即生效，刷新间隔下次穿透时生效。, 3, 1
return

BtnRevertSettings:
    shape := snapShape
    width := snapWidth
    height := snapHeight
    corner := snapCorner
    rate := snapRate
    animMode := snapAnim
    compatMode := snapCompat
    minimizeOthers := snapMinOthers
    penMode := snapPenMode
    winlist := snapWinlist
    BuildRegion()
    if running
        RefreshActiveHoles()
    Gui, Settings:Destroy
    settingsHwnd := 0
return

BtnDefaultSettings:
    shape := "circle"
    width := 600
    height := 600
    corner := 0
    rate := 20
    animMode := 1

    SetShape := 1
    GuiControl, Settings:Choose, SetShape, 1
    GuiControl, Settings:, SetRate, 20
    GuiControl, Settings:, SetRateEdit, 20
    GuiControl, Settings:, SetAnimMode, 2
    GuiControl, Settings:, SetCompat, 1
    GuiControl, Settings:, SetMinOthers, 0
    minimizeOthers := 0
    GuiControl, Settings:, SetPenMode, 0
    penMode := 0
    UpdateShapeControls()
    SyncControls()
    BuildRegion()
    Preview()
    if running
        RefreshActiveHoles()
return

; 清除穿透残留：枚举所有顶层可见窗口，把任何「带着真实区域（残留洞口）」的窗口复位成普通矩形。
; 用途：万一出现关洞 / 退出后洞口卡住不消失的极端情况，点一下（或工具退出时自动）即可兜底清掉，不需要重启电脑。
; 只清「本工具进程之外的窗口」+ 默认跳过当前正在管理的洞窗，避免误伤正在使用的洞或本程序自身。
; ignoreRunningGuard=1 时（工具退出用）不做运行中跳过，把所有带区域的窗都清一遍。
ClearAllResidue(ignoreRunningGuard := 0) {
    global settingsHwnd, running, HoleHwnd1, HoleHwnd2, g_deepHwnds
    pid := A_PID
    cnt := 0
    WinGet, idList, List
    Loop, %idList% {
        h := idList%A_Index%
        if !h
            continue
        if (h = settingsHwnd)   ; 跳过本工具设置面板
            continue
        WinGet, wpid, PID, ahk_id %h%
        if (wpid = pid)   ; 跳过本工具自身进程的所有窗口（含 Fade 覆盖窗 / 主窗，退出时由 OS 销毁）
            continue
        if !DllCall("IsWindowVisible", "ptr", h)
            continue
        ; 运行中：跳过当前正在管理的洞窗，避免与刷新计时器互相打架（那些由正常关洞逻辑处理）
        if (!ignoreRunningGuard && running) {
            if (h = HoleHwnd1 || h = HoleHwnd2)
                continue
            skip := false
            for kk, vv in g_deepHwnds
                if (vv = h) {
                    skip := true
                    break
                }
            if (skip)
                continue
        }
        hr := DllCall("gdi32\CreateRectRgn", "int",0,"int",0,"int",1,"int",1,"ptr")
        ret := DllCall("user32\GetWindowRgn", "ptr", h, "ptr", hr)
        DllCall("gdi32\DeleteObject", "ptr", hr)
        ; ret>0（SIMPLEREGION / COMPLEXREGION）说明该窗带着真实区域，即残留洞口
        if (ret > 0) {
            DllCall("user32\SetWindowRgn", "ptr", h, "ptr", 0, "int", 1)
            cnt++
        }
    }
    return cnt
}

BtnClearResidue:
    global settingsHwnd
    GuiControl, Settings:, ClearResidueMsg, 正在扫描全部窗口…
    cnt := ClearAllResidue()
    if (cnt = 0)
        GuiControl, Settings:, ClearResidueMsg, 未发现穿透残留
    else
        GuiControl, Settings:, ClearResidueMsg, 已清除 %cnt% 个窗口的穿透残留
return

SettingsGuiClose:
SettingsGuiEscape:
    Gosub, BtnRevertSettings
return

; =======================================================================
;  热键逻辑
; =======================================================================
$`::
{
    dbg("HOTKEY DOWN")
    if WinActive("窗口洞洞波 - 设置")
    {
        SendInput, ``
        return
    }
    ; 自动重复：同一按住期间的系统重复按下直接忽略。
    ; 注意：被 hook 的同一按键上 GetKeyState/KeyWait 都看不见物理按住，
    ; 所以“按住时长”不能靠轮询；改成：按下启动一次性计时器，到阈值即开（无需松开）。
    if (backtickHeld)
        return
    backtickHeld := true
    dbg("DOWN running=" . running)
    tDown := A_TickCount
    if (!running)               ; 洞未开：启动一次性计时器，按住达阈值即开洞（不依赖松开）
    {
        openDelay := -g_longPressMs
        SetTimer, OpenTimer, %openDelay%
    }
    return
}

$` up::
{
    dbg("UP enter running=" . running . " backtickHeld=" . backtickHeld)
    if ! backtickHeld
        return
    backtickHeld := 0
    SetTimer, OpenTimer, Off     ; 取消待触发的开洞计时器
    heldMs := A_TickCount - tDown
    dbg("RELEASE heldMs=" . heldMs)
    if (running)                ; 洞已开
    {
        if (penMode = 1)         ; 按住穿透模式：松手必关
        {
            Gosub, DoClose
            return
        }
        if (heldMs < g_longPressMs - 100)   ; 常驻模式：仅短按关闭
            Gosub, DoClose
        return
    }
    if (heldMs >= g_longPressMs - 100)   ; 洞未开 + 长按：松开时也开（兜底）
    {
        Gosub, DoOpen
        return
    }
    ; 洞未开 + 短按：还原输入的 ` 字符（距上次操作够久才发，避免关洞后误发）
    if (A_TickCount - StartTime > 2000)
        SendInput, ``
    return
}

OpenTimer:                     ; 按住达到阈值、尚未松开 -> 立即开洞（开后即常驻，无需松开）
    dbg("OpenTimer fire running=" . running . " backtickHeld=" . backtickHeld)
    if (backtickHeld && !running)
        Gosub, DoOpen
return

; 开洞期间定时检查前台窗口：若活动窗口已真正离开「当前穿透上下文」，自动关闭全部穿透，
; 避免洞留在旧窗口上造成多窗口残留/清不掉。
; 判定“安全、不关”的任一条件满足即保留（防误关）：
;   1) 程序自身窗口（设置面板）            2) 开洞时刻的前台窗(g_acAnchor)——鼠标移到别处、焦点没变也保留
;   3) 洞所在窗本身(HoleHwnd1)             4) 已显式钻入的深层窗(g_deepHwnds)
;   5) 当前光标处(洞实际位置)的层叠栈含该前台窗——点击穿透到下层
; 仅当以上都不满足、且持续 250ms，才判定为“切到无关窗口”并关闭。
AutoCloseCheck:
    if !running || !HoleHwnd1
        return
    ; 安全 0：洞所在窗或任一深层穿透窗已被销毁（被关闭 / 崩溃）→ 整条隧道失效，立即彻底收洞，避免残留。
    ; 直接修用户反馈的 bug：多层穿透时关闭最前窗，后面窗的洞会一直卡着不消失。
    if !DllCall("IsWindow", "ptr", HoleHwnd1) {
        dbg("AutoClose: HoleHwnd1 已销毁 -> DoClose")
        Gosub, DoClose
        return
    }
    for k, v in g_deepHwnds
        if !DllCall("IsWindow", "ptr", v) {
            dbg("AutoClose: 深层穿透窗 " . v . " 已销毁 -> DoClose")
            Gosub, DoClose
            return
        }
    fg := DllCall("user32\GetForegroundWindow", "ptr")
    if !fg {
        g_acOutside := 0
        return
    }
    root := DllCall("user32\GetAncestor", "ptr", fg, "uint", 3, "ptr")   ; GA_ROOT
    if !root
        root := fg
    if (root = settingsHwnd) {  ; 程序自身窗口（设置面板）不触发关闭
        g_acOutside := 0
        return
    }
    ; 安全 2：开洞时刻的前台窗（用户“当前所在”窗口）——即便鼠标移到别的窗、焦点没变也保留
    if (root = g_acAnchor) {
        g_acOutside := 0
        return
    }
    ; 安全 3：洞所在窗本身
    hw1root := DllCall("user32\GetAncestor", "ptr", HoleHwnd1, "uint", 3, "ptr")
    if !hw1root
        hw1root := HoleHwnd1
    if (root = hw1root) {
        g_acOutside := 0
        return
    }
    ; 安全 4：已显式钻入的深层窗
    for k, v in g_deepHwnds
        if (v = root) {
            g_acOutside := 0
            return
        }
    ; 安全 5：当前光标(洞实际位置)处层叠栈含前台窗 —— 视为点击穿透到下层，保留
    MouseGetPos, px, py
    stack := GetLayerStack(px, py)
    for k, v in stack
        if (v = root) {
            g_acOutside := 0
            return
        }
    ; 真正离开了穿透上下文：需稳定持续一小段时间才关，避免焦点闪动误关
    if (!g_acOutside)
        g_acOutside := A_TickCount
    else if (A_TickCount - g_acOutside > 250) {
        dbg("AutoClose: fg=" . root . " 持续在穿透上下文外 -> DoClose")
        Gosub, DoClose
    }
return

; --------------------------- 开洞（热键按住 / /punch 共用） ---------------------------
DoOpen:
dbg("DoOpen enter running=" . running)
if running
return
; 防御性清理：确保没有残留的多层穿透目标
TeardownDeep()
if g_animLog
FileDelete, %A_ScriptDir%\anim_log.txt
MouseGetPos, , ,nowid
; 只有开了「最小化其他窗口」才去枚举 / 最小化；否则洞后面就是真正的下层窗口
minimizedList := ""
if minimizeOthers
{
arr := EnumerateAltTabWindows()
altTabWindows:=""
for k, v in arr
{
WinGetClass, winClass, ahk_id %v%
if nowid=%v%
continue
WinGet, MMstate, MinMax , ahk_id %v%
if (MMstate>0.5) or (!MMstate)
altTabWindows .= v "`n"
}
WinGet, exename, ProcessName, ahk_id %nowid%
loop, Parse, winlist, `n, `r
{
if exename=%A_LoopField%
altTabWindows:=""
}
; 只最小化真正要腾开的窗口，并记录清单；关闭时按此清单「静默还原」
loop, Parse, altTabWindows, `n, `r
{
if !A_LoopField
continue
WinGet, exename, ProcessName, ahk_id %A_LoopField%
skipThis := false
loop, Parse, winlist, `n, `r
{
if (A_LoopField != "") and (exename = A_LoopField)
{
skipThis := true
break
}
}
if skipThis
continue
DisableWindowTransitions(A_LoopField, 1)
WinMinimize, ahk_id %A_LoopField%
DisableWindowTransitions(A_LoopField, 0)
minimizedList .= A_LoopField "`n"
}
}
SetTimer, AnimTick, Off
g_scale := (animMode > 0) ? 0.25 : 1.0
timer(1,rate)
if (animMode > 0)
{
animTarget := 1
animSlow := 0
animDurMs := (animMode = 2) ? 360 : 220   ; mode 2「柔和收洞」开洞也稍慢更柔
animStart := A_TickCount
SetTimer, AnimTick, 14
}
Toggle:=!Toggle
Pause:=0
running:=!running
g_acOutside := 0
; 记录开洞时刻的前台窗口为锚点：AutoCloseCheck 以此为基准判定“是否切到无关窗口”，
; 这样即使开洞时光标窗≠焦点窗、或开洞后鼠标移到别处，都不会误关。
fg := DllCall("user32\GetForegroundWindow", "ptr")
g_acAnchor := fg ? DllCall("user32\GetAncestor", "ptr", fg, "uint", 3, "ptr") : 0
if !g_acAnchor
    g_acAnchor := fg
SetTimer, AutoCloseCheck, 150   ; 开洞期间监测：切到隧道外窗口时自动关闭，避免多窗口残留
return
#if Toggle
; 关闭（点按 ` 触发或动画收尾；开/关判定见上方 $` / $` up::）
DoClose:
dbg("DoClose enter animMode=" . animMode . " running=" . running)
SetTimer, AutoCloseCheck, Off
g_acAnchor := 0
SetTimer, AnimTick, Off
g_useFade := 0
if (animMode = 2)
{
    ; 尝试用「我们自己的分层覆盖窗」做「透明→内容」交叉淡入（洞保持打开、下面仍是实时透出画面，
    ; 覆盖窗显示被穿透窗内容快照、整窗不透明度 0→255）。失败则回退到区域收缩动画。
    if HoleHwnd1
        g_useFade := SetupFadeOverlay(HoleHwnd1)
}
if (animMode > 0)
{
animTarget := 0
animSlow := 0
animDurMs := (animMode = 2) ? 520 : 220   ; mode 2「渐变过渡」更慢更柔（分层覆盖窗做透明→内容交叉淡入）
animStart := A_TickCount
SetTimer, AnimTick, 14
}
else
FinalizeClose()
Toggle := 0
return
; 多层穿透：Ctrl+↓ 往更深处打一层，Ctrl+↑ 收回到更浅一层
^Up::
ChangeLayer(-1)
return
^Down::
ChangeLayer(1)
return
#if

; =======================================================================
;  关闭动画
; =======================================================================
AnimTick:
{
if g_animLog
FileAppend, % "t" A_TickCount "`n", %A_ScriptDir%\anim_log.txt
; 按「真实经过时间」推进，而不是按固定帧数：
; 目标窗口越重、每帧越贵时自动用更少的帧，但总时长仍锁在 animDurMs 左右，
; 不会出现「窗口一卡就慢吞吞拖很久」。
elapsed := A_TickCount - animStart
t := elapsed / animDurMs
if (t > 1)
t := 1
; 缓动：mode 2「渐变过渡」用 smootherstep（更柔、起步收尾都极缓，像慢慢化开）；
; 其余用 smoothstep。
if (animMode = 2)
t := t * t * t * (t * (t * 6 - 15) + 10)
else
t := t * t * (3 - 2 * t)
; mode 2 且覆盖窗已就绪：用「透明→内容」交叉淡入，不再收缩区域（洞保持打开，下面仍是实时透出画面）。
if (animMode = 2 && g_useFade)
{
    alpha := Round(255 * t)
    UpdateFadeOverlay(alpha)
    if (elapsed >= animDurMs)
    {
        SetTimer, AnimTick, Off
        HideFadeOverlay()
        FinalizeClose()
    }
    return
}
if (animTarget)
g_scale := 0.25 + 0.75 * t
else
g_scale := 1 - t
; 动画期间用低分辨率区域 + 跳过强制重绘，保证每帧都在 60fps 预算内
if HoleHwnd1
{
tReg := A_TickCount
RefreshRegionAnim(HoleHwnd1)
regCost := A_TickCount - tReg
if g_animLog
FileAppend, % "r" regCost "`n", %A_ScriptDir%\anim_log.txt
; 第一帧就很贵，说明目标窗口在区域变更上很费（浏览器最典型：SetWindowRgn 会同步给它发
; WM_SIZE / WM_PAINT，它自己的线程忙，一次要几十毫秒）。
; 注意 A_TickCount 只有 ~15.6ms 精度，读到的值本身是量化过的，所以阈值要留够余量。
; 这种情况下别硬撑动画时长 —— 与其卡着慢慢收缩，不如快速收完，观感反而更利落。
; mode 2 即便重也只缩短到 320（仍比默认柔），避免重型窗口上拖太久。
if (regCost > 40) and !animSlow
{
animSlow := 1
animDurMs := (animMode = 2) ? 320 : 110
}
}
if (elapsed >= animDurMs)
{
SetTimer, AnimTick, Off
if (animTarget)
{
g_scale := 1.0
if HoleHwnd1
RefreshRegion(HoleHwnd1, 1)
}
else
FinalizeClose()
}
}
return

; =======================================================================
;  函数
; =======================================================================
Clamp(v, lo, hi) {
    if (v < lo)
        return lo
    if (v > hi)
        return hi
    return v
}

ShapeFromIndex(idx) {
    if (idx = 2)
        return "ellipse"
    if (idx = 3)
        return "rect"
    if (idx = 4)
        return "triangle"
    if (idx = 5)
        return "heart"
    return "circle"
}

ShapeToIndex(s) {
    if (s = "ellipse")
        return 2
    if (s = "rect")
        return 3
    if (s = "triangle")
        return 4
    if (s = "heart")
        return 5
    return 1
}

; 同时生成 g_region（完整分辨率）和 g_animRegion（动画用低分辨率）。
; 实测：1900 点的区域每帧要 24ms，超过 14ms 的定时器间隔，动画必然卡顿；
; 降到 64~96 点后约 7~9ms/帧，才能跑满 60fps。
BuildRegion() {
    global g_region, g_animRegion, shape, width, height, corner
    if (shape = "rect") {
        if (corner > 0)
            g_region := makeRoundRect(width, height, corner)
        else
            g_region := makeRect(width, height)
        g_animRegion := g_region
    } else if (shape = "triangle") {
        g_region := makeTriangle(width)
        g_animRegion := g_region
    } else if (shape = "heart") {
        g_region := heart4tidbit(Round(width / 2))
        g_animRegion := heart4tidbit(Round(width / 2), 96)
    } else {
        g_region := makeEllipse(width, height)
        g_animRegion := makeEllipse(width, height, 64)
    }
}

RefreshActiveHoles() {
    global HoleHwnd1, HoleHwnd2
    if HoleHwnd1
        RefreshRegion(HoleHwnd1, 1)
    if HoleHwnd2
        RefreshRegion(HoleHwnd2, 1)
}

UpdateShapeControls() {
    global SetShape, hSetWidth
    idx := SetShape + 0
    ; 第一行：不同形状对应不同的尺寸名
    if (idx = 1)
        GuiControl, Settings:, LblSize1, 半    径：
    else if (idx = 4)
        GuiControl, Settings:, LblSize1, 边    长：
    else
        GuiControl, Settings:, LblSize1, 宽    度：
    ; 正圆的滑块量程是半径 60-1200（即直径 120-2400）
    if (idx = 1)
        SetSliderRange(hSetWidth, 60, 1200)
    else
        SetSliderRange(hSetWidth, 60, 2400)

    ; 第二行（高度）只在椭圆 / 矩形下有意义
    if (idx = 2) or (idx = 3)
    {
        GuiControl, Settings:Enable, SetHeight
        GuiControl, Settings:Enable, SetHeightEdit
        GuiControl, Settings:Enable, LblSize2
        GuiControl, Settings:Enable, Unit2
    }
    else
    {
        GuiControl, Settings:Disable, SetHeight
        GuiControl, Settings:Disable, SetHeightEdit
        GuiControl, Settings:Disable, LblSize2
        GuiControl, Settings:Disable, Unit2
    }

    ; 圆角只在矩形下有意义
    if (idx = 3)
    {
        GuiControl, Settings:Enable, SetCorner
        GuiControl, Settings:Enable, SetCornerEdit
        GuiControl, Settings:Enable, LblCorner
        GuiControl, Settings:Enable, UnitCorner
    }
    else
    {
        GuiControl, Settings:Disable, SetCorner
        GuiControl, Settings:Disable, SetCornerEdit
        GuiControl, Settings:Disable, LblCorner
        GuiControl, Settings:Disable, UnitCorner
    }
}

; 用 TBM_SETRANGEMIN / TBM_SETRANGEMAX 动态调整滑块量程
; 注意：SET 版是 WM_USER+7 / WM_USER+8（0x0407 / 0x0408），GET 版才是 0x0401 / 0x0402
SetSliderRange(hSl, lo, hi) {
    if !hSl
        return
    DllCall("user32\SendMessage", "ptr", hSl, "uint", 0x0407, "uptr", 1, "ptr", lo, "ptr")
    DllCall("user32\SendMessage", "ptr", hSl, "uint", 0x0408, "uptr", 1, "ptr", hi, "ptr")
    return
}

; 按当前 shape 把 width/height/corner 回写到各控件（正圆写半径 = 直径/2）
SyncControls() {
    global shape, width, height, corner
    if (shape = "circle")
    {
        r := Round(width / 2)
        GuiControl, Settings:, SetWidth, %r%
        GuiControl, Settings:, SetWidthEdit, %r%
    }
    else
    {
        GuiControl, Settings:, SetWidth, %width%
        GuiControl, Settings:, SetWidthEdit, %width%
    }
    GuiControl, Settings:, SetHeight, %height%
    GuiControl, Settings:, SetHeightEdit, %height%
    GuiControl, Settings:, SetCorner, %corner%
    GuiControl, Settings:, SetCornerEdit, %corner%
}

; 从面板控件读回 shape / width / height / corner（按当前形状语义换算外接尺寸）
; 注意：正圆在面板上编辑的是「半径」，这里乘 2 转成外接直径。
PullShapeState() {
    global shape, width, height, corner
    global SetShape, SetWidth, SetHeight, SetCorner
    shape := ShapeFromIndex(SetShape)
    if (shape = "circle")
    {
        width := Clamp(SetWidth, 60, 1200) * 2
        height := width
        corner := 0
    }
    else if (shape = "ellipse") or (shape = "rect")
    {
        width := Clamp(SetWidth, 60, 2400)
        height := Clamp(SetHeight, 60, 2400)
        corner := (shape = "rect") ? Clamp(SetCorner, 0, 300) : 0
    }
    else
    {
        ; 三角形 / 心形只有一个尺寸
        width := Clamp(SetWidth, 60, 2400)
        height := width
        corner := 0
    }
    return
}

ApplyLive() {
    global running
    PullShapeState()
    BuildRegion()
    if running
        RefreshActiveHoles()
    ; 预览重绘合并到一次定时器，拖动滑块时更跟手
    RequestPreview()
}

; 合并预览重绘（节流），避免每拖动一格都重建整张位图导致卡顿
RequestPreview() {
    global previewScheduled
    if previewScheduled
        return
    previewScheduled := 1
    SetTimer, DoPreviewTick, -25
    return
}
DoPreviewTick:
    previewScheduled := 0
    Preview()
return

IsAutostartOn() {
    RegRead, autostartVal, HKCU\Software\Microsoft\Windows\CurrentVersion\Run, 窗口洞洞波
    return (ErrorLevel = 0)
}

SetAutostartOn(enable) {
    if (enable)
        RegWrite, Reg_SZ, HKCU\Software\Microsoft\Windows\CurrentVersion\Run, 窗口洞洞波, "%A_ScriptFullPath%"
    else if IsAutostartOn()
        RegDelete, HKCU\Software\Microsoft\Windows\CurrentVersion\Run, 窗口洞洞波
}

UpdateAutostartMenu() {
    state := IsAutostartOn() ? "Check" : "UnCheck"
    Menu, Tray, %state%, 开机自启动
}

SaveIni() {
    global iniPath, radius, rate, shape, winlist, width, height, corner, animEnabled, compatMode, minimizeOthers, penMode
    nl := "`r`n"
    wl := RegExReplace(winlist, "`r`n", "`n")
    wl := RegExReplace(wl, "`n", "`r`n")
    ; [radius] 段落里存真正的半径，方便和 0.2 的写法对照
    rad := (shape = "circle") ? Round(width / 2) : width
    content := "[settings]" nl
    content .= "shape=" shape nl
    content .= "width=" width nl
    content .= "height=" height nl
    content .= "corner=" corner nl
    content .= "rate=" rate nl
    content .= "animMode=" animMode nl
    content .= "compat=" compatMode nl
    content .= "minothers=" minimizeOthers nl
    content .= "penmode=" penMode nl
    content .= nl
    content .= "[radius]" nl
    content .= "radius=" rad nl
    content .= nl
    content .= "[winlist]" nl
    if (wl != "")
        content .= wl nl
    file := FileOpen(iniPath, "w", "UTF-16")
    if IsObject(file) {
        file.Write(content)
        file.Close()
    }
}

; --------------------------- 预览绘制（GDI 位图 → Picture 控件） ---------------------------
Preview() {
    global g_region, settingsHwnd, previewBmp, width, height, shape, corner, previewHwnd
    if !settingsHwnd
        return
    ; 注意 1：ControlGetPos 不支持用控件关联变量名当 ControlID。
    ; 注意 2：Preview() 也可能由定时器线程调用，此时 GuiControlGet..Hwnd 可能取不到控件，
    ;        因此控件句柄在创建面板时只取一次，存在 previewHwnd 里复用。
    hPrev := previewHwnd
    if !hPrev
        return
    VarSetCapacity(crc, 16, 0)
    DllCall("GetClientRect", "ptr", hPrev, "ptr", &crc, "int")
    cw := NumGet(crc, 8, "int")
    ch := NumGet(crc, 12, "int")
    if (cw < 20) or (ch < 20)
        return

    hdcScreen := DllCall("GetDC", "ptr", 0, "ptr")
    memdc := DllCall("CreateCompatibleDC", "ptr", hdcScreen, "ptr")
    hbm := DllCall("CreateCompatibleBitmap", "ptr", hdcScreen, "int", cw, "int", ch, "ptr")
    oldbm := DllCall("SelectObject", "ptr", memdc, "ptr", hbm, "ptr")

    ; 白底
    VarSetCapacity(rc, 16, 0)
    NumPut(0, rc, 0, "int")
    NumPut(0, rc, 4, "int")
    NumPut(cw, rc, 8, "int")
    NumPut(ch, rc, 12, "int")
    whiteBrush := DllCall("GetStockObject", "int", 0, "ptr")
    DllCall("FillRect", "ptr", memdc, "ptr", &rc, "ptr", whiteBrush, "int")

    ; 形状轮廓
    if IsObject(g_region) {
        n := g_region.MaxIndex()
        if (n > 1) {
            pad := 14
            minX := 2147483647, maxX := -2147483647, minY := 2147483647, maxY := -2147483647
            for k, pt in g_region {
                if (pt.x < minX)
                    minX := pt.x
                if (pt.x > maxX)
                    maxX := pt.x
                if (pt.y < minY)
                    minY := pt.y
                if (pt.y > maxY)
                    maxY := pt.y
            }
            gw := maxX - minX
            gh := maxY - minY
            if (gw < 1)
                gw := 1
            if (gh < 1)
                gh := 1
            sx := (cw - pad * 2) / gw
            sy := (ch - pad * 2) / gh
            scale := (sx < sy) ? sx : sy
            cx := cw / 2 - (minX + maxX) * scale / 2
            cy := ch / 2 - (minY + maxY) * scale / 2

            VarSetCapacity(pts, (n + 1) * 8, 0)
            i := 0
            for k, pt in g_region {
                NumPut(Round(cx + pt.x * scale), pts, i * 8, "int")
                NumPut(Round(cy + pt.y * scale), pts, i * 8 + 4, "int")
                i += 1
            }
            NumPut(Round(cx + g_region[1].x * scale), pts, i * 8, "int")
            NumPut(Round(cy + g_region[1].y * scale), pts, i * 8 + 4, "int")

            ; CreatePen 的 COLORREF 是 0x00BBGGRR，这里 = RGB(230,126,34) 橙色
            shapePen := DllCall("CreatePen", "int", 0, "int", 2, "uint", 0x00227EE6, "ptr")
            shapeOld := DllCall("SelectObject", "ptr", memdc, "ptr", shapePen, "ptr")
            DllCall("Polyline", "ptr", memdc, "ptr", &pts, "int", n + 1, "int")
            DllCall("SelectObject", "ptr", memdc, "ptr", shapeOld, "ptr")
            DllCall("DeleteObject", "ptr", shapePen, "int")
        }
    }

    ; 1 像素灰色边框
    grayPen := DllCall("CreatePen", "int", 0, "int", 1, "uint", 0x00C8C8C8, "ptr")
    hollowBrush := DllCall("GetStockObject", "int", 5, "ptr")
    oldPen := DllCall("SelectObject", "ptr", memdc, "ptr", grayPen, "ptr")
    oldBrush := DllCall("SelectObject", "ptr", memdc, "ptr", hollowBrush, "ptr")
    DllCall("Rectangle", "ptr", memdc, "int", 0, "int", 0, "int", cw - 1, "int", ch - 1, "int")
    DllCall("SelectObject", "ptr", memdc, "ptr", oldBrush, "ptr")
    DllCall("SelectObject", "ptr", memdc, "ptr", oldPen, "ptr")
    DllCall("DeleteObject", "ptr", grayPen, "int")

    ; 清理 GDI 对象
    DllCall("SelectObject", "ptr", memdc, "ptr", oldbm, "ptr")
    DllCall("DeleteDC", "ptr", memdc, "int")
    DllCall("ReleaseDC", "ptr", 0, "ptr", hdcScreen, "int")

    GuiControl, Settings:, PreviewPic, HBITMAP:*%hbm%
    if previewBmp
        DllCall("DeleteObject", "ptr", previewBmp, "int")
    previewBmp := hbm

    if (shape = "circle")
        info := "正圆`n半径 " Round(width / 2) " 像素（直径 " width "）"
    else if (shape = "ellipse")
        info := "椭圆`n宽 " width " × 高 " height
    else if (shape = "rect")
        info := "矩形`n宽 " width " × 高 " height "，圆角 " corner
    else if (shape = "triangle")
        info := "三角形`n边长 " width " 像素"
    else
        info := "心形`n宽度 " width " 像素"
    GuiControl, Settings:, PreviewInfo, %info%
}

; --------------------------- 形状生成 ---------------------------
; n = 0 表示按周长自动取点；动画时传一个较小的 n 换取流畅度
makeEllipse(w, h, n := 0) {
    static pi := ATan(1) * 4
    rx := w / 2
    ry := h / 2
    ; 默认分辨率压到 128 段：圆在任意尺寸下视觉无差别，但每帧 SetWindowRgn 从 ~24ms 降到 ~3ms，
    ; 这是文件夹穿透卡顿的根因（稳态 g_region 此前用 ~1884 点）。
    if (n <= 0)
        n := 128
    n := (n > 1990) ? 1990 : n
    if (n < 24)
        n := 24
    pts := []
    loop, % n
    {
        t := 2 * pi * (A_Index - 1) / n
        pts.push({x: Round(rx * Cos(t)), y: Round(ry * Sin(t))})
    }
    pts.push(pts[1])
    return pts
}

makeRect(w, h) {
    hw := w // 2
    hh := h // 2
    return [{x: -hw, y: -hh}, {x: hw, y: -hh}, {x: hw, y: hh}, {x: -hw, y: hh}, {x: -hw, y: -hh}]
}

makeRoundRect(w, h, c) {
    static pi := ATan(1) * 4
    hw := w // 2
    hh := h // 2
    if (c > w // 2)
        c := w // 2
    if (c > h // 2)
        c := h // 2
    if (c < 1)
        return makeRect(w, h)
    seg := 12
    corners := [{cx: hw - c, cy: -hh + c, a0: 1.5 * pi, a1: 2 * pi}
              , {cx: hw - c, cy: hh - c, a0: 0, a1: 0.5 * pi}
              , {cx: -hw + c, cy: hh - c, a0: 0.5 * pi, a1: pi}
              , {cx: -hw + c, cy: -hh + c, a0: pi, a1: 1.5 * pi}]
    pts := []
    for k, cc in corners
    {
        loop, % seg + 1
        {
            a := cc.a0 + (cc.a1 - cc.a0) * (A_Index - 1) / seg
            pts.push({x: Round(cc.cx + c * Cos(a)), y: Round(cc.cy + c * Sin(a))})
        }
    }
    pts.push(pts[1])
    return pts
}

heart4tidbit(r := 100, n := 0)
{
    if (r < 5)
        r := 5
    if (n <= 0)
        n := 128
    n := (n >= 997) ? 997 : n
    if (n < 16)
        n := 16
    region := []
    oY := -r // 2
    loop, % n
    {
        x := -2 + 4 * (A_Index - 1) / (n - 1)
        y := -Sqrt(1 - (Abs(x) - 1) ** 2)
        region.push({x: x * r, y: y * r + oY})
    }
    loop, % n
    {
        x := 2 - 4 * (A_Index - 1) / (n - 1)
        y := 3 * Sqrt(1 - Sqrt(Abs(x / 2)))
        region.push({x: x * r, y: y * r + oY})
    }
    return region
}

makeTriangle(side := 100) {
    heigth := Round(side * Sqrt(3) / 2)
    region := [{x: 0, y: 0}, {x: side // 2, y: heigth}, {x: -side // 2, y: heigth}, {x: 0, y: 0}]
    oY := -heigth // 2
    for k, pt in region
        pt.y += oY
    return region
}

; --------------------------- 穿透计时器 ---------------------------
exit() {
    ; 1) 先清掉本工具管理的所有洞（主洞 / 第二洞 / 深层），最关键，确保不留穿透残留。
    ;    放在最前：即便下面还原材质那步出错，洞也一定先清干净。
    timer(0)
    timer2(0)
    TeardownDeep()
    ; 2) 兜底：扫描并清除任何仍带区域（残留洞口）的窗口——连本工具没记录到的也清，
    ;    专门解决「托盘退出时进程立刻结束、目标窗重绘/区域消息来不及处理 → 洞口卡住不消失」。
    ClearAllResidue(1)
    ; 3) 最后还原被关掉 DWM 材质的窗口（即便这步出错也不影响上面的清洞）。
    try
        RestoreAllCompat()
    catch e
        dbg("exit RestoreAllCompat error: " . e.Message)
    ; 4) 销毁渐变覆盖窗（若淡入动画中途退出，避免冻结的快照窗残留）
    HideFadeOverlay()
    ; 还原定时器精度设置
    DllCall("winmm\timeEndPeriod", "uint", 1)
    ExitApp
    return
}

timer(state, rate := 100) {
    static timerFn, paused, hWin, aot
    global HoleHwnd1, compatMode
    if (state = 0) {
        dbg("timer(0) enter hWin=" . hWin . " timerFn=" . (timerFn ? "y" : "n"))
        if timerFn
            SetTimer, % timerFn, Off
        if !hWin
            return
        ClearWindowRegion(hWin)
        ; 关洞后再异步兜底重绘一次（不带 UPDATENOW，不阻塞）。
        ; 区域撤销本身会让系统重绘实心部分，但移动过程中若因 redraw=0 留下过残留，这一下确保补干净。
        DllCall("RedrawWindow", "ptr", hWin, "ptr", 0, "ptr", 0, "uint", 0x0001 | 0x0080)
        if !aot
            WinSet, AlwaysOnTop, off, % "ahk_id " hWin
        ; 关洞不再切换窗口的 DWM 背景材质、不再整窗重绘 → 不再整窗闪。
        ; 材质只在第一次开洞时关一次（ApplyWindowCompat），工具退出时统一还原（RestoreAllCompat）。
        hWin := "", timerFn := "", aot := "", paused := 0
        HoleHwnd1 := 0
        return
    } else if (timerFn) {
        if (state = -1) {
            SetTimer, % timerFn, Off
            return paused := 1
        } else if paused {
            SetTimer, % timerFn, On
            return paused := 0
        } else {
            SetTimer, % timerFn, Off
        }
    }
    if !hWin {
        MouseGetPos, , , hWin
        if compatMode
            ApplyWindowCompat(hWin)
        WinGet, aot, ExStyle, % "ahk_id " hWin
        aot &= 0x8
        if !aot
            WinSet, AlwaysOnTop, On, % "ahk_id " hWin
    }
    HoleHwnd1 := hWin
    timerFn := Func("timerFunction").Bind(hWin)
    timerFn.Call(1)
    SetTimer, % timerFn, % rate
    return
}

timer2(state, rate := 100) {
    static timerFn, paused, hWin, aot
    global HoleHwnd2
    if (state = 0) {
        if timerFn
            SetTimer, % timerFn, Off
        if !hWin
            return
        ClearWindowRegion(hWin)
        DllCall("RedrawWindow", "ptr", hWin, "ptr", 0, "ptr", 0, "uint", 0x0001 | 0x0080)
        if !aot
            WinSet, AlwaysOnTop, off, % "ahk_id " hWin
        hWin := "", timerFn := "", aot := "", paused := 0
        HoleHwnd2 := 0
        return
    } else if (timerFn) {
        if (state = -1) {
            SetTimer, % timerFn, Off
            return paused := 1
        } else if paused {
            SetTimer, % timerFn, On
            return paused := 0
        } else {
            SetTimer, % timerFn, Off
        }
    }
    if !hWin {
        MouseGetPos, , , hWin
        WinGet, aot, ExStyle, % "ahk_id " hWin
        aot &= 0x8
        if !aot
            WinSet, AlwaysOnTop, On, % "ahk_id " hWin
    }
    HoleHwnd2 := hWin
    timerFn := Func("timerFunction").Bind(hWin)
    timerFn.Call(1)
    SetTimer, % timerFn, % rate
    return
}

timerFunction(hWin, resetStatic := 0) {
    static px, py
    global g_scale, HoleHwnd1
    ; 自停：本窗已不是当前主洞窗（已收洞 / 被销毁），立即停掉自身计时器并返回，
    ; 不再重设区域 —— 这是关洞 / 销毁后「绝对不再残留洞口」的兜底（即便 SetTimer Off 在主线程外没即时生效）。
    if (hWin != HoleHwnd1 || !DllCall("IsWindow", "ptr", hWin)) {
        SetTimer, % A_ThisTimer, Off
        return
    }
    WinGetPos, wx, wy, , , % "ahk_id " hWin
    CoordMode, Mouse, Screen
    MouseGetPos, x, y
    x -= wx
    y -= wy
    if (x = px && y = py && !resetStatic)
        return
    else
        px := x, py := y
    ; 重新钉死 z 序（HWND_TOPMOST=-1，SWP_NOMOVE|NOSIZE|NOACTIVATE）：
    ; 洞口窗只在开洞时开了一次置顶，正常情况下不会再动它。
    ; ⚠️ 这里曾经用 GetWindow(hWin, GW_HWNDFIRST) != hWin 判断「是否被反超」，是错的：
    ; 只要桌面上存在任何别的置顶窗口（例如 WorkBuddy 主窗本身就是置顶的），
    ; 该判断就恒为真 → 每帧都发一次 SetWindowPos(TOPMOST)，
    ; z 序一旦被扰动（典型：后面新打开一个窗口）就会看到窗口「跳一下」。
    ; 改成只看 WS_EX_TOPMOST(0x8)：置顶还在就一帧都不发（正常情况恒真，零开销、零抖动）；
    ; 只有目标窗确实丢了置顶（topmost 被清掉）时才补一次。
    WinGet, exStyle, ExStyle, % "ahk_id " hWin
    if !(exStyle & 0x8)
        DllCall("SetWindowPos", "ptr", hWin, "ptr", -1, "int", 0, "int", 0, "int", 0, "int", 0, "uint", 0x0002 | 0x0001 | 0x0010)
    RefreshRegion(hWin, 1, 0, 1)
    return
}

; 动画专用：直接用 SetWindowRgn 且 redraw=0。
; 为什么快：WinSet,Region 默认会触发一次同步重绘（实测每帧 31~47ms，是关闭卡顿的主因）；
; 而窗口的 backing surface 里本来就有内容，区域只是裁切 —— 不重绘也不会错，
; 只是动画中间帧的新露出部分可能短暂偏旧，动画结束会补一帧完整重绘。
RefreshRegionAnim(hWin) {
    global g_scale, g_animRegion
    if !hWin
        return
    if !g_animRegion
        return
    WinGetPos, wx, wy, , , % "ahk_id " hWin
    CoordMode, Mouse, Screen
    MouseGetPos, x, y
    SetWindowRgnRaw(hWin, g_scale, x - wx, y - wy, g_animRegion, 0)
    return
}

; 彻底清除窗口区域（恢复成普通矩形窗口）。
; 用 Windows 官方 SetWindowRgn(hWnd, NULL, bRedraw=1)：比 AHK 的 "WinSet, Region,," 更可靠，
; 避免在「托盘退出 / 关洞 / 收洞」场景下残留洞口（即用户反馈的「洞口固定住不消失」）。
ClearWindowRegion(hWin) {
    if !hWin || !DllCall("IsWindow", "ptr", hWin)
        return
    DllCall("user32\SetWindowRgn", "ptr", hWin, "ptr", 0, "int", 1)
}

SetWindowRgnRaw(hWin, scale, dx, dy, region, redraw) {
    static prevHoleRgn := 0, prevHwnd := 0
    WinGetPos, wx, wy, w, h, % "ahk_id " hWin
    n := region.MaxIndex()
    total := 5 + n
    VarSetCapacity(pts, total * 8, 0)
    ; 外框：把整个窗口圈起来
    NumPut(0, pts, 0, "int")
    NumPut(0, pts, 4, "int")
    NumPut(0, pts, 8, "int")
    NumPut(h, pts, 12, "int")
    NumPut(w, pts, 16, "int")
    NumPut(h, pts, 20, "int")
    NumPut(w, pts, 24, "int")
    NumPut(0, pts, 28, "int")
    NumPut(0, pts, 32, "int")
    NumPut(0, pts, 36, "int")
    ; 洞：ALTERNATE(奇偶) 填充规则下，内圈会被挖空
    i := 5
    for k, pt in region
    {
        NumPut(Round(dx + pt.x * scale), pts, i * 8, "int")
        NumPut(Round(dy + pt.y * scale), pts, i * 8 + 4, "int")
        i += 1
    }
    hrgn := DllCall("gdi32\CreatePolygonRgn", "ptr", &pts, "int", total, "int", 1, "ptr")
    if !hrgn
        return
    ; SetWindowRgn 会接管这个 region，不要自己 DeleteObject
    DllCall("user32\SetWindowRgn", "ptr", hWin, "ptr", hrgn, "int", redraw)

    ; ---------------- 残留修复：把「上一帧还是洞、这一帧变回实心」的那一小条标记为待重绘 ----------------
    ; 为什么必须补：SetWindowRgn(redraw=0) 只改区域、不发 WM_PAINT。洞移走之后，
    ; 原洞位置在 DWM 的合成结果里仍然是上一帧「透出后窗」的画面，而窗口自己没重绘，
    ; 于是那块就永久留着后窗内容 —— 正是用户反馈的「穿透窗口残留未消去」（资源管理器最明显）。
    ; 做法：算差集 prevHole ∖ curHole（洞移走后重新变实心的一条），只把这一小条交给
    ; RedrawWindow 异步重绘（带 ALLCHILDREN，见下）。故意不做 RDW_UPDATENOW —— 不阻塞
    ; 定时器，移动依旧流畅，而窗口会在自己的 WM_PAINT 里把这一条补上（实测 0.8ms/帧）。
    if (hWin != prevHwnd) {
        if (prevHoleRgn)
            DllCall("gdi32\DeleteObject", "ptr", prevHoleRgn)
        prevHoleRgn := 0
        prevHwnd := hWin
    }
    VarSetCapacity(cpt, 8, 0)
    DllCall("user32\ClientToScreen", "ptr", hWin, "ptr", &cpt)
    offX := dx - (NumGet(cpt, 0, "int") - wx)   ; 窗口坐标 → 客户区坐标（InvalidateRgn 用客户区）
    offY := dy - (NumGet(cpt, 4, "int") - wy)
    VarSetCapacity(cpts, n * 8, 0)
    j := 0
    hbx0 := 999999, hby0 := 999999, hbx1 := -999999, hby1 := -999999
    for k, pt in region
    {
        cpx := Round(offX + pt.x * scale)
        cpy := Round(offY + pt.y * scale)
        NumPut(cpx, cpts, j * 8, "int")
        NumPut(cpy, cpts, j * 8 + 4, "int")
        if (cpx < hbx0)
            hbx0 := cpx
        if (cpx > hbx1)
            hbx1 := cpx
        if (cpy < hby0)
            hby0 := cpy
        if (cpy > hby1)
            hby1 := cpy
        j += 1
    }
    holeArea := (hbx1 - hbx0) * (hby1 - hby0)
    curHole := DllCall("gdi32\CreatePolygonRgn", "ptr", &cpts, "int", n, "int", 1, "ptr")
    if (curHole) {
        if (prevHoleRgn) {
            solid := DllCall("gdi32\CreateRectRgn", "int", 0, "int", 0, "int", 0, "int", 0, "ptr")
            if (solid) {
                ; CombineRgn(dest, src1, src2, RGN_DIFF=4)：dest = src1 ∖ src2
                if (DllCall("gdi32\CombineRgn", "ptr", solid, "ptr", prevHoleRgn, "ptr", curHole, "int", 4) != 0) {
                    VarSetCapacity(rc, 16, 0)
                    DllCall("gdi32\GetRgnBox", "ptr", solid, "ptr", &rc)
                    bw := NumGet(rc, 8, "int") - NumGet(rc, 0, "int")
                    bh := NumGet(rc, 12, "int") - NumGet(rc, 4, "int")
                    ; 差集非空、且不超过洞本身包围盒的 4 倍才重绘：
                    ; 正常移动（含快速移动）只会是一条月牙，远小于这个上限；
                    ; 形状切换 / 换窗口这类大变化交给调用方的完整重绘，避免误伤性能。
                    ; ⚠️ 必须用 RedrawWindow + RDW_ALLCHILDREN，不能用 InvalidateRgn：
                    ; 资源管理器的内容区在子窗口里（SHELLDLL_DefView / DirectUIHWND），
                    ; 父窗口 BeginPaint 会把子窗口区域排除掉，只失效父窗口的话子窗口里的残留补不到。
                    ; RDW_INVALIDATE(0x0001) | RDW_ALLCHILDREN(0x0080)，故意不加 RDW_UPDATENOW / RDW_ERASE：
                    ; 异步、不擦背景，既不阻塞定时器也不闪。
                    if (bw > 0 && bh > 0 && bw * bh <= 4 * holeArea)
                        DllCall("user32\RedrawWindow", "ptr", hWin, "ptr", 0, "ptr", solid, "uint", 0x0001 | 0x0080)
                }
                DllCall("gdi32\DeleteObject", "ptr", solid)
            }
        }
        DllCall("gdi32\DeleteObject", "ptr", prevHoleRgn)
        prevHoleRgn := curHole
    }
    return
}

RefreshRegion(hWin, force := 0, region := 0, noRedraw := 0) {
    global g_scale
    if !hWin
        return
    WinGetPos, wx, wy, , , % "ahk_id " hWin
    CoordMode, Mouse, Screen
    MouseGetPos, x, y
    WinSetRegion(hWin, g_scale, x - wx, y - wy, inverted, region, noRedraw)
    return
}

WinSetRegion(hWin, scale, dx := 0, dy := 0, inverted := false, region := 0, noRedraw := 0) {
    global g_region, g_animRegion, compatMode, redrawTick
    if !region
        region := g_region
    if !region
        return
    ; 稳态移动走 redraw=0 快速路径（与动画 RefreshRegionAnim 一致）：
    ; 直接 SetWindowRgn 且 redraw=0，不强制同步重绘。区域只是裁切，由 DWM 自动重新合成，
    ; 每帧省下 31~47ms 的整窗重绘 —— 这是「移动圆洞明显卡顿」的根因。
    ; 开洞/关洞/改形状等低频场景仍走下方 WinSet,Region（redraw=1）以保证一次完整重绘。
    if (noRedraw) {
        SetWindowRgnRaw(hWin, scale, dx, dy, region, 0)
        return
    }
    if !inverted {
        WinGetPos, , , w, h, % "ahk_id " hWin
        regionDefinition := "0-0 0-" h " " w "-" h " " w "-0 0-0 "
    } else
        regionDefinition := ""
    for k, pt in region
        regionDefinition .= Round(dx + pt.x * scale) "-" Round(dy + pt.y * scale) " "
    WinSet, Region, % regionDefinition, % "ahk_id " hWin
    ; 稳态不再做强制重绘：区域裁切由系统处理（窗口可见区域变化时系统自动发 WM_PAINT 重绘实心部分），
    ; 材质开关只在「第一次开洞」时由 ApplyWindowCompat 做一次完整重绘，关洞不再整窗重绘（见 RestoreAllCompat）。
    ; 此前每 10 tick 强制整窗（含所有子控件）同步重绘（RedrawWindow RDW_ALLCHILDREN|RDW_UPDATENOW），
    ; 是文件夹卡顿 + 整窗闪的次因，已移除。
}

; --------------------------- 浏览器/视频兼容处理 ---------------------------
; 关键：Win11 的「现代窗口」(资源管理器 / 设置 / 记事本 / WinUI 应用) 带 DWM 背景材质
; (Mica / Mica Alt / Acrylic)。此时 SetWindowRgn 挖出的洞不会被 DWM 交给下层窗口，
; 而是被那块模糊材质填满 —— 用户看到的就是「洞后是一层模糊/灰色背景盖住了」，
; 而且每次改区域 DWM 都要重算一次模糊，实测单次 40~100ms，必然卡顿。
; 关掉 backdrop 材质后：洞正常透出下层窗口，单次 SetWindowRgn 从 63ms 降到 4ms。
ApplyWindowCompat(hWin) {
    global compatMode, g_compatHwnds, g_compatOrigCorner, g_compatOrigBackdrop
    if !compatMode
        return
    ; 已为该窗关过材质则跳过：避免重复切换 DWM 背景材质 + 整窗重绘 → 关洞/再开洞时整窗闪。
    for k, h in g_compatHwnds
        if (h = hWin)
            return
    oc := "", ob := ""
    VarSetCapacity(v, 4, 0)
    if !DllCall("dwmapi\DwmGetWindowAttribute", "ptr", hWin, "int", 33, "int*", v, "int", 4)
        oc := v
    VarSetCapacity(v, 4, 0)
    if !DllCall("dwmapi\DwmGetWindowAttribute", "ptr", hWin, "int", 38, "int*", v, "int", 4)
        ob := v
    dontRound := 1
    DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hWin, "int", 33, "int*", dontRound, "int", 4)
    backdropNone := 1   ; DWMSBT_NONE
    DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hWin, "int", 38, "int*", backdropNone, "int", 4)
    ForceRedraw(hWin)
    g_compatHwnds.Push(hWin)
    g_compatOrigCorner.Push(oc)
    g_compatOrigBackdrop.Push(ob)
}

RestoreAllCompat() {
    global g_compatHwnds, g_compatOrigCorner, g_compatOrigBackdrop, compatMode
    if !compatMode
        return
    ; 工具退出时统一还原所有被关过材质的窗口（主洞）：关洞过程不再逐窗还原 → 不再整窗闪。
    for k, h in g_compatHwnds {
        if !DllCall("IsWindow", "ptr", h)
            continue
        oc := g_compatOrigCorner[k]
        ob := g_compatOrigBackdrop[k]
        if (oc != "")
            DllCall("dwmapi\DwmSetWindowAttribute", "ptr", h, "int", 33, "int*", oc, "int", 4)
        if (ob != "")
            DllCall("dwmapi\DwmSetWindowAttribute", "ptr", h, "int", 38, "int*", ob, "int", 4)
        ForceRedraw(h)
    }
    g_compatHwnds := []
    g_compatOrigCorner := []
    g_compatOrigBackdrop := []
}

ForceRedraw(hwnd) {
    if !hwnd
        return
    DllCall("SetWindowPos", "ptr", hwnd, "ptr", 0, "int", 0, "int", 0, "int", 0, "int", 0, "uint", 0x0020 | 0x0002 | 0x0001 | 0x0004 | 0x0010)
    ; 关键：关闭/打开时整窗重绘必须「异步 + 不擦背景」——
    ; 旧写法带 RDW_ERASE(0x0004) 会先刷白底、RDW_UPDATENOW(0x0080) 同步阻塞，
    ; 对 Win11 现代窗口（资源管理器/设置/记事本）就是「整窗白闪」的根因。
    ; 改成与差集补重绘一致的 RDW_INVALIDATE|RDW_FRAME|RDW_ALLCHILDREN（不含 ERASE/UPDATENOW），
    ; 窗口在自己 WM_PAINT 里重绘真实内容（不刷白），DWM 背景材质切换由 DWM 自行重新合成。
    DllCall("RedrawWindow", "ptr", hwnd, "ptr", 0, "ptr", 0, "uint", 0x0001 | 0x0100 | 0x0400)
}

; --------------------------- 关闭「透明→内容」交叉淡入（mode 2） ---------------------------
; 思路：开洞时目标窗被挖了洞、透出后面；关洞时不再用区域收缩（那是「擦除」不是「渐变」）。
; 改为浮一个【我们自己的分层覆盖窗】压在被穿透窗上面：覆盖窗显示被穿透窗内容快照，
; 整窗不透明度 SourceConstantAlpha 从 0→255 渐变。0=全透（与开着洞无缝，看得到后面）；
; 255=全不透（=被穿透窗内容）。于是观感就是「洞区域从透明平滑过渡到窗口内容」——用户要的效果。
; 关键点：分层窗是工具自己的窗（WS_EX_LAYERED），不是给任意目标窗加分层样式，
; 所以不会触发此前「WS_EX_LAYERED 给任意窗加透明→全白屏」的 Bug。
SetupFadeOverlay(hwnd) {
    global g_fadeHwnd, g_fadeDC, g_fadeBmp, g_fadeWW, g_fadeWH, g_fadeX, g_fadeY, g_fadeOk
    g_fadeOk := 0
    if !hwnd || !DllCall("IsWindow", "ptr", hwnd)
        return 0
    ; 目标窗口的屏幕矩形（含边框），用物理像素，和 UpdateLayeredWindow 的坐标体系一致
    VarSetCapacity(rc, 16, 0)
    if !DllCall("user32\GetWindowRect", "ptr", hwnd, "ptr", &rc)
        return 0
    wx := NumGet(rc, 0, "int"), wy := NumGet(rc, 4, "int")
    ww := NumGet(rc, 8, "int") - wx
    wh := NumGet(rc, 12, "int") - wy
    if (ww <= 0 || wh <= 0)
        return 0
    ; 建一张与窗口等大的 32bpp DIB，用 PrintWindow 把被穿透窗的「完整内容」画进去（忽略挖洞区域）
    VarSetCapacity(bi, 40, 0)
    NumPut(40, bi, 0, "uint")
    NumPut(ww, bi, 4, "int")
    NumPut(-wh, bi, 8, "int")    ; 负高度 = 顶向下（与屏幕方向一致）
    NumPut(1, bi, 12, "ushort")
    NumPut(32, bi, 14, "ushort")
    hdc := DllCall("gdi32\CreateCompatibleDC", "ptr", 0, "ptr")
    if !hdc
        return 0
    VarSetCapacity(ppv, A_PtrSize, 0)
    hbmp := DllCall("gdi32\CreateDIBSection", "ptr", hdc, "ptr", &bi, "uint", 0, "ptr", &ppv, "ptr", 0, "uint", 0, "ptr")
    if !hbmp {
        DllCall("gdi32\DeleteDC", "ptr", hdc)
        return 0
    }
    DllCall("gdi32\SelectObject", "ptr", hdc, "ptr", hbmp)
    ; PrintWindow 抓完整内容（带 PW_RENDERFULLCONTENT=2，对 DWM/现代窗也能抓到内容）；失败再试普通模式(0)
    if !DllCall("user32\PrintWindow", "ptr", hwnd, "ptr", hdc, "uint", 2)
        DllCall("user32\PrintWindow", "ptr", hwnd, "ptr", hdc, "uint", 0)
    ; 我们的分层覆盖窗：WS_EX_LAYERED(0x80000) + 点击穿透(0x20)；这是工具自己的窗，安全
    Gui, Fade: -Caption +E0x80000 +E0x20 +AlwaysOnTop +ToolWindow +LastFound
    Gui, Fade: Show, % "x" wx " y" wy " w" ww " h" wh " NoActivate"
    g_fadeHwnd := WinExist()
    if !g_fadeHwnd {
        DllCall("gdi32\DeleteObject", "ptr", hbmp)
        DllCall("gdi32\DeleteDC", "ptr", hdc)
        return 0
    }
    ; 置顶，确保在被穿透窗之上
    DllCall("user32\SetWindowPos", "ptr", g_fadeHwnd, "ptr", -1, "int", 0, "int", 0, "int", 0, "int", 0, "uint", 0x0002 | 0x0001)
    g_fadeDC := hdc, g_fadeBmp := hbmp
    g_fadeX := wx, g_fadeY := wy, g_fadeWW := ww, g_fadeWH := wh
    g_fadeOk := 1
    UpdateFadeOverlay(0)   ; 透明度 0 = 完全透明，与「开着洞」无缝衔接
    return 1
}

UpdateFadeOverlay(alpha) {
    global g_fadeOk, g_fadeHwnd, g_fadeDC, g_fadeWW, g_fadeWH, g_fadeX, g_fadeY
    if !g_fadeOk
        return
    if (alpha < 0)
        alpha := 0
    if (alpha > 255)
        alpha := 255
    VarSetCapacity(ptDst, 8, 0)
    NumPut(g_fadeX, ptDst, 0, "int")
    NumPut(g_fadeY, ptDst, 4, "int")
    VarSetCapacity(sz, 8, 0)
    NumPut(g_fadeWW, sz, 0, "int")
    NumPut(g_fadeWH, sz, 4, "int")
    VarSetCapacity(ptSrc, 8, 0)
    VarSetCapacity(blend, 4, 0)
    NumPut(0, blend, 0, "uchar")    ; BlendOp = AC_SRC_OVER
    NumPut(0, blend, 1, "uchar")    ; BlendFlags
    NumPut(alpha, blend, 2, "uchar") ; SourceConstantAlpha（整窗不透明度）
    NumPut(0, blend, 3, "uchar")    ; AlphaFormat = 0：忽略源 alpha，只用 SourceConstantAlpha
    DllCall("user32\UpdateLayeredWindow", "ptr", g_fadeHwnd, "ptr", 0, "ptr", &ptDst, "ptr", &sz, "ptr", g_fadeDC, "ptr", &ptSrc, "uint", 0, "ptr", &blend, "uint", 0)
}

HideFadeOverlay() {
    global g_fadeOk, g_fadeHwnd, g_fadeDC, g_fadeBmp
    if !g_fadeOk
        return
    Gui, Fade: Hide
    if (g_fadeDC)
        DllCall("gdi32\DeleteDC", "ptr", g_fadeDC)
    if (g_fadeBmp)
        DllCall("gdi32\DeleteObject", "ptr", g_fadeBmp)
    g_fadeDC := 0, g_fadeBmp := 0, g_fadeOk := 0
    Gui, Fade: Destroy
}

; --------------------------- 收尾 ---------------------------
FinalizeClose() {
    global g_scale, running, running2, Pause, StartTime
    global HoleHwnd1, g_deepHwnds, g_deepTimers, g_deepOrigCorner, g_deepOrigBackdrop, compatMode, minimizedList, nowid
    dbg("FinalizeClose start HoleHwnd1=" . HoleHwnd1 . " deep=" . g_deepHwnds.Length())
    global minimizedList, nowid
    SetTimer, AutoCloseCheck, Off
    g_scale := 1.0
    timer2(0)
    timer(0)
    TeardownDeep()
    Pause := 0
    running := 0
    running2 := 0
    StartTime := A_TickCount
    ; 静默还原：只还原「真正被最小化」的窗口（不再对白名单窗口做多余的最小化/还原），
    ; 并在还原瞬间关闭该窗口的 DWM 过渡动画，避免一串窗口接连弹出、闪烁。
    if (minimizedList != "")
    {
        arrM := StrSplit(minimizedList, "`n", "`r")
        loop, % arrM.length()
        {
            thiswin := arrM[A_Index]
            if !thiswin
                continue
            if !DllCall("IsWindow", "ptr", thiswin)
                continue
            DisableWindowTransitions(thiswin, 1)
            WinRestore, ahk_id %thiswin%
            DisableWindowTransitions(thiswin, 0)
        }
        minimizedList := ""
    }
    if nowid
        WinActivate, ahk_id %nowid%
    return
}

; =======================================================================
;  多层穿透（Ctrl+↑/↓）：在层叠窗口间「钻隧」到指定深度
;  模型：最前层(HoleHwnd1)始终打洞；Ctrl+↓ 多打一层（把更深的窗也挖洞，露出再后面）；
;        Ctrl+↑ 收掉最深的洞。深度 d 表示已打洞层数，可见/可交互目标 = 第 d+1 层。
;  注意：深层窗只挖洞 + 关材质，不抢置顶（保持原本 z 序），否则会打乱层叠关系。
; =======================================================================

; 枚举屏幕点 (sx,sy) 处、从前往后的层叠窗口列表（过滤自身进程/任务栏/最小化/隐藏/非覆盖点）
GetLayerStack(sx, sy) {
    result := []
    top := DllCall("user32\WindowFromPoint", "int", sx, "int", sy, "ptr")
    if !top
        return result
    root := DllCall("user32\GetAncestor", "ptr", top, "uint", 3, "ptr")  ; GA_ROOT=3
    if !root
        root := top
    myPid := DllCall("kernel32\GetCurrentProcessId", "uint")
    cur := root
    iter := 0
    loop {
        if !cur || (iter > 200)
            break
        iter++
        if !DllCall("user32\IsWindowVisible", "ptr", cur, "int")
            break
        pid := 0
        DllCall("user32\GetWindowThreadProcessId", "ptr", cur, "uint*", pid, "uint")
        if (pid = myPid) {
            cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
            continue
        }
        WinGetClass, cls, ahk_id %cur%
        if (cls = "Shell_TrayWnd" || cls = "Progman" || cls = "WorkerW") {
            cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
            continue
        }
        VarSetCapacity(rc, 16, 0)
        if !DllCall("user32\GetWindowRect", "ptr", cur, "ptr", &rc)
            break
        l := NumGet(rc, 0, "int"), t := NumGet(rc, 4, "int")
        r := NumGet(rc, 8, "int"), b := NumGet(rc, 12, "int")
        if (r - l <= 0 || b - t <= 0) {
            cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
            continue
        }
        if (sx < l || sx > r || sy < t || sy > b) {
            cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
            continue
        }
        WinGet, mm, MinMax, % "ahk_id " cur
        if (mm = -1) {
            cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
            continue
        }
        cloaked := 0
        if !DllCall("dwmapi\DwmGetWindowAttribute", "ptr", cur, "int", 14, "uint*", cloaked, "int", 4)
            if (cloaked) {
                cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
                continue
            }
        result.Push(cur)
        cur := DllCall("user32\GetWindow", "ptr", cur, "uint", 2, "ptr")
    }
    return result
}

; 改变穿透深度：dir=+1 更深一层，dir=-1 收浅一层
; 关键修正（第二十轮）：此前用 FindBehind 从洞口窗(HoleHwnd1)沿裸 z 序(GW_HWNDNEXT)
; 向下找「第一个覆盖它矩形」的窗作为下一层——这有两个致命缺陷：
;   ① HoleHwnd1 是置顶窗，裸 z 序下方第一个往往是「别的置顶窗」（如本工具主窗），
;      它通过了可见/非自身 pid/非任务栏等过滤，被误当穿透目标 → AddDeepHole 打错窗，
;      表现为 Ctrl+↓ “毫无反应”。
;   ② 即便到正常窗，它也只是「z 序上第一个与洞口窗矩形相交」的窗，未必是光标洞后
;      真正可见的那一层，于是钻到了洞外窗，依旧看不到层级变化。
; 现改为以「光标处真实层栈」为准：洞口窗本身被挖了洞，WindowFromPoint 会跳过它，
; 直接返回洞后第一扇可见窗；再跳过已打过洞的层，选下一层打洞。这样无论光标是否正好
; 压在目标窗、是否有其它置顶窗夹在中间，都能精确钻到洞后真正可见的那一层。
ChangeLayer(dir) {
    global running, HoleHwnd1, g_deepHwnds, g_deepTimers, g_deepOrigCorner, g_deepOrigBackdrop, compatMode, rate
    if !running || !HoleHwnd1
        return
    CoordMode, Mouse, Screen
    MouseGetPos, cx, cy
    stack := GetLayerStack(cx, cy)   ; 光标处自顶向下的真实可见窗栈（已跳过洞口窗本体）
    if (dir > 0) {
        ; 选第一扇「尚未被打过洞」的窗作为下一层
        target := 0
        for k, w in stack {
            hit := false
            for kk, v in g_deepHwnds
                if (v = w) {
                    hit := true
                    break
                }
            if !hit {
                target := w
                break
            }
        }
        if !target {
            dbg("ChangeLayer dir=1 target=0 (光标洞后无更多可见层)")
            return
        }
        dbg("ChangeLayer dir=1 target=" . target . " stack=" . stack.Length())
        AddDeepHole(target)
        ShowLayerTip(1 + g_deepHwnds.Length(), stack.Length())
    } else {
        if (g_deepHwnds.Length() <= 0)
            return
        dbg("ChangeLayer dir=-1 retract")
        RemoveDeepHole()
        ShowLayerTip(g_deepHwnds.Length(), stack.Length())
    }
}

AddDeepHole(hwnd) {
    global g_deepHwnds, g_deepTimers, g_deepOrigCorner, g_deepOrigBackdrop, compatMode, rate
    if !hwnd || !DllCall("IsWindow", "ptr", hwnd)
        return
    if compatMode {
        oc := "", ob := ""
        ApplyWindowCompatEx(hwnd, oc, ob)
        g_deepOrigCorner.Push(oc)
        g_deepOrigBackdrop.Push(ob)
    } else {
        g_deepOrigCorner.Push("")
        g_deepOrigBackdrop.Push("")
    }
    g_deepHwnds.Push(hwnd)
    dbg("AddDeepHole " . hwnd)
    fn := Func("timerFunctionDeep").Bind(hwnd)
    fn.Call(1)   ; resetStatic=1，立即打洞
    SetTimer, % fn, % rate
    g_deepTimers.Push(fn)
}

RemoveDeepHole() {
    global g_deepHwnds, g_deepTimers, g_deepOrigCorner, g_deepOrigBackdrop, compatMode
    if !g_deepHwnds.Length()
        return
    hwnd := g_deepHwnds.Pop()
    fn := g_deepTimers.Pop()
    oc := g_deepOrigCorner.Pop()
    ob := g_deepOrigBackdrop.Pop()
    dbg("RemoveDeepHole " . hwnd)
    if fn
        SetTimer, % fn, Off
    if hwnd {
        ClearWindowRegion(hwnd)
        DllCall("RedrawWindow", "ptr", hwnd, "ptr", 0, "ptr", 0, "uint", 0x0001 | 0x0080)
        if (compatMode) {
            if (oc != "")
                DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "int", 33, "int*", oc, "int", 4)
            if (ob != "")
                DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "int", 38, "int*", ob, "int", 4)
            ForceRedraw(hwnd)
        }
    }
}

TeardownDeep() {
    while (g_deepHwnds.Length())
        RemoveDeepHole()
}

; 深层窗的穿透计时器：只跟随光标刷新区域，不抢置顶（保持层叠顺序）
timerFunctionDeep(hWin, resetStatic := 0) {
    static px, py
    global g_deepHwnds
    ; 自停：本窗已不是当前任一深层穿透窗（已收洞 / 被销毁 / 已退层），
    ; 立即停掉自身计时器并返回，不再重设区域 —— 与 timerFunction 同款兜底，
    ; 确保关洞 / 销毁 / 退层后「绝对不再残留洞口」。
    if !hWin || !DllCall("IsWindow", "ptr", hWin) {
        SetTimer, % A_ThisTimer, Off
        return
    }
    stillDeep := 0
    for k, v in g_deepHwnds
        if (v = hWin) {
            stillDeep := 1
            break
        }
    if !stillDeep {
        SetTimer, % A_ThisTimer, Off
        return
    }
    WinGetPos, wx, wy, , , % "ahk_id " hWin
    CoordMode, Mouse, Screen
    MouseGetPos, x, y
    x -= wx
    y -= wy
    if (x = px && y = py && !resetStatic)
        return
    else
        px := x, py := y
    RefreshRegion(hWin, 1, 0, 1)
}

; 逐窗关闭材质（DWMSBT_NONE），与 ApplyWindowCompat 等价但只作用于传入的 hwnd（深层层穿透用）
ApplyWindowCompatEx(hwnd, ByRef oc, ByRef ob) {
    if !hwnd
        return
    VarSetCapacity(v, 4, 0)
    if !DllCall("dwmapi\DwmGetWindowAttribute", "ptr", hwnd, "int", 33, "int*", v, "int", 4)
        oc := v
    VarSetCapacity(v, 4, 0)
    if !DllCall("dwmapi\DwmGetWindowAttribute", "ptr", hwnd, "int", 38, "int*", v, "int", 4)
        ob := v
    dontRound := 1
    DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "int", 33, "int*", dontRound, "int", 4)
    backdropNone := 1
    DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "int", 38, "int*", backdropNone, "int", 4)
    ForceRedraw(hwnd)
}

ShowLayerTip(d, m) {
    CoordMode, Mouse, Screen
    MouseGetPos, mx, my
    ToolTip, % "穿透层 " d " / " m, mx + 22, my + 22
    SetTimer, ClearLayerTip, -900
}

ClearLayerTip:
ToolTip
return

; 开关单个窗口的 DWM 过渡动画，让最小化 / 还原「瞬移」，不产生连串闪动
DisableWindowTransitions(hwnd, disable) {
    static DWMWA_TRANSITIONS_FORCEDISABLED := 3
    if !hwnd
        return
    v := disable ? 1 : 0
    DllCall("dwmapi\DwmSetWindowAttribute", "ptr", hwnd, "int", DWMWA_TRANSITIONS_FORCEDISABLED, "int*", v, "int", 4)
    return
}

; --------------------------- 窗口枚举（沿用原版） ---------------------------
EnumerateAltTabWindows()
{
    AltTabList := []
    WinGet, list, List
    loop % list
    {
        if IsAltTabWindow(list%A_Index%)
            AltTabList.Push(list%A_Index%)
    }
    return AltTabList
}
IsAltTabWindow(hWnd)
{
    static WS_EX_APPWINDOW := 0x40000, WS_EX_TOOLWINDOW := 0x80, DWMWA_CLOAKED := 14, DWM_CLOAKED_SHELL := 2, WS_EX_NOACTIVATE := 0x8000000, GA_PARENT := 1, GW_OWNER := 4, MONITOR_DEFAULTTONULL := 0, VirtualDesktopExist, PropEnumProcEx := RegisterCallback("PropEnumProcEx", "Fast", 4)
    if (VirtualDesktopExist = "")
    {
        OSbuildNumber := StrSplit(A_OSVersion, ".")[3]
        if (OSbuildNumber < 14393)
            VirtualDesktopExist := 0
        else
            VirtualDesktopExist := 1
    }
    if !DllCall("IsWindowVisible", "uptr", hWnd)
        return
    DllCall("DwmApi\DwmGetWindowAttribute", "uptr", hWnd, "uint", DWMWA_CLOAKED, "uint*", cloaked, "uint", 4)
    if (cloaked = DWM_CLOAKED_SHELL)
        return
    if (realHwnd(DllCall("GetAncestor", "uptr", hwnd, "uint", GA_PARENT, "ptr")) != realHwnd(DllCall("GetDesktopWindow", "ptr")))
        return
    WinGetClass, winClass, ahk_id %hWnd%
    if (winClass = "Windows.UI.Core.CoreWindow")
        return
    if (winClass = "ApplicationFrameWindow")
    {
        VarSetCapacity(ApplicationViewCloakType, 4, 0)
        DllCall("EnumPropsEx", "uptr", hWnd, "ptr", PropEnumProcEx, "ptr", &ApplicationViewCloakType)
        if (NumGet(ApplicationViewCloakType, 0, "int") = 1)
            return
    }
    WinGet, exStyles, ExStyle, ahk_id %hWnd%
    if (exStyles & WS_EX_APPWINDOW)
    {
        if DllCall("GetProp", "uptr", hWnd, "str", "ITaskList_Deleted", "ptr")
            return
        if (VirtualDesktopExist = 0) or IsWindowOnCurrentVirtualDesktop(hwnd)
            return true
        else
            return
    }
    if (exStyles & WS_EX_TOOLWINDOW) or (exStyles & WS_EX_NOACTIVATE)
        return
    loop
    {
        hwndPrev := hwnd
        hwnd := DllCall("GetWindow", "uptr", hwnd, "uint", GW_OWNER, "ptr")
        if !hwnd
        {
            if DllCall("GetProp", "uptr", hwndPrev, "str", "ITaskList_Deleted", "ptr")
                return
            if (VirtualDesktopExist = 0) or IsWindowOnCurrentVirtualDesktop(hwndPrev)
                return true
            else
                return
        }
        if DllCall("IsWindowVisible", "uptr", hwnd)
            return
        WinGet, exStyles, ExStyle, ahk_id %hwnd%
        if ((exStyles & WS_EX_TOOLWINDOW) or (exStyles & WS_EX_NOACTIVATE)) and !(exStyles & WS_EX_APPWINDOW)
            return
    }
}
GetLastActivePopup(hwnd)
{
    static GA_ROOTOWNER := 3
    hwnd := DllCall("GetAncestor", "uptr", hwnd, "uint", GA_ROOTOWNER, "ptr")
    hwnd := DllCall("GetLastActivePopup", "uptr", hwnd, "ptr")
    return hwnd
}
IsWindowOnCurrentVirtualDesktop(hwnd)
{
    static IVirtualDesktopManager
    if !IVirtualDesktopManager
        IVirtualDesktopManager := ComObjCreate(CLSID_VirtualDesktopManager := "{AA509086-5CA9-4C25-8F95-589D3C07B48A}", IID_IVirtualDesktopManager := "{A5CD92FF-29BE-454C-8D04-D82879FB3F1B}")
    DllCall(NumGet(NumGet(IVirtualDesktopManager+0), 3*A_PtrSize), "ptr", IVirtualDesktopManager, "uptr", hwnd, "int*", onCurrentDesktop)
    return onCurrentDesktop
}
PropEnumProcEx(hWnd, lpszString, hData, dwData)
{
    if (StrGet(lpszString, "UTF-16") = "ApplicationViewCloakType")
    {
        NumPut(hData, dwData+0, 0, "int")
        return false
    }
    return true
}
realHwnd(hwnd)
{
    VarSetCapacity(var, 8, 0)
    NumPut(hwnd, var, 0, "uint64")
    return NumGet(var, 0, "uint")
}
